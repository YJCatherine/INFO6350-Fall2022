//
//  CompanyQuote.swift
//  stockApp
//
//  Created by Yujie Zhang on 12/10/2022.
//

import Foundation

class CompanyQuote {
    var symbol: String = ""
    var name: String = ""
    var price: Float = 0.0
}
